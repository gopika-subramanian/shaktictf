import "./main";
import $ from "jquery";
import { clear_notification_counter } from "../utils";

$(() => {
  clear_notification_counter();
});
